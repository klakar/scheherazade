<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>@default</name>
    <message>
        <location filename="test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation type="unfinished">God Morgon</translation>
    </message>
</context>
<context>
    <name>story</name>
    <message>
        <location filename="story.py" line="220"/>
        <source>&amp;Story</source>
        <translation type="unfinished">&amp;Berättelse</translation>
    </message>
    <message>
        <location filename="story.py" line="189"/>
        <source>Story</source>
        <translation type="unfinished">Berättelse</translation>
    </message>
    <message>
        <location filename="story.py" line="537"/>
        <source>Slide Title</source>
        <translation type="unfinished">Bildrubrik</translation>
    </message>
    <message>
        <location filename="story.py" line="538"/>
        <source>Content</source>
        <translation type="unfinished">Innehåll</translation>
    </message>
    <message>
        <location filename="story.py" line="345"/>
        <source>Message!</source>
        <translation type="unfinished">Meddelande!</translation>
    </message>
    <message>
        <location filename="story.py" line="445"/>
        <source>Slide %s/%s</source>
        <translation type="unfinished">Bild %s/%s</translation>
    </message>
    <message>
        <location filename="story.py" line="523"/>
        <source>The main Story Title</source>
        <translation type="unfinished">Berättelsens Huvudtitel</translation>
    </message>
    <message>
        <location filename="story.py" line="280"/>
        <source>Continue?</source>
        <translation type="unfinished">Fortsätt?</translation>
    </message>
    <message>
        <location filename="story.py" line="280"/>
        <source>Remove Current Slide?</source>
        <translation type="unfinished">Ta bort denna bild?</translation>
    </message>
    <message>
        <location filename="story.py" line="345"/>
        <source>This file does not exist!</source>
        <translation type="unfinished">Denna fil finns inte!</translation>
    </message>
    <message>
        <location filename="story.py" line="355"/>
        <source>Save New or Replace Current StoryFile</source>
        <translation type="unfinished">Spara Ny eller ersätt nuvarande Berättelse</translation>
    </message>
    <message>
        <location filename="story.py" line="388"/>
        <source>Select folder to generate story</source>
        <translation type="unfinished">Välj katalog att skapa Berättelse</translation>
    </message>
    <message>
        <location filename="story.py" line="313"/>
        <source>Open Story file</source>
        <translation type="unfinished">Öppna Storyfil</translation>
    </message>
    <message>
        <location filename="story.py" line="340"/>
        <source>Error!</source>
        <translation type="unfinished">Fel!</translation>
    </message>
    <message>
        <location filename="story.py" line="340"/>
        <source>The story file: %s
Could not be opened!

%s</source>
        <translation type="unfinished">Storyfilen: %s 
Kunde inte öppnas!

%s</translation>
    </message>
</context>
<context>
    <name>storyDockWidgetBase</name>
    <message>
        <location filename="story_dockwidget_base.ui" line="786"/>
        <source>Title</source>
        <translation type="unfinished">Titel</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="249"/>
        <source>Style</source>
        <translation type="unfinished">Stil</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="376"/>
        <source>Story File</source>
        <translation type="unfinished">Berrättelse Fil</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="608"/>
        <source>Slide n/nn</source>
        <translation type="unfinished">Bild n/nn</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="985"/>
        <source>Zoom</source>
        <translation type="unfinished">Zoom</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="898"/>
        <source>Position</source>
        <translation type="unfinished">Position</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="27"/>
        <source>Story</source>
        <translation type="unfinished">Berättelse</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="43"/>
        <source>&lt;b&gt;Main&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Generellt&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="367"/>
        <source>&lt;b&gt;File&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Filer&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="563"/>
        <source>&lt;b&gt;Slides&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Bilder&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="156"/>
        <source>Main Story Title</source>
        <translation type="unfinished">Berättelsent Titel</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="167"/>
        <source>Template</source>
        <translation type="unfinished">Mall</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="238"/>
        <source>Select Story Template</source>
        <translation type="unfinished">Välj Mall</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="347"/>
        <source>Select Story Style</source>
        <translation type="unfinished">Välj Stil</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="453"/>
        <source>Current Story Save File</source>
        <translation type="unfinished">Nuvarande Berättelsefil</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="460"/>
        <source>Clear Story Save Path</source>
        <translation type="unfinished">Rensa Berättelsesökväg</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="492"/>
        <source>Open Story</source>
        <translation type="unfinished">Öppna Berättelse</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="507"/>
        <source>Save Story</source>
        <translation type="unfinished">Spara Berättelse</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="522"/>
        <source>Create/Publish Story</source>
        <translation type="unfinished">Skapa/Publicera Berättelse</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="572"/>
        <source>Move to Previous Slide</source>
        <translation type="unfinished">Flytta till Tidigare</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="590"/>
        <source>Move Slide Earlier</source>
        <translation type="unfinished">Flytta bild tidigare</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="615"/>
        <source>Move Slide Later</source>
        <translation type="unfinished">Flytta bild till senare</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="630"/>
        <source>Move to Next Slide</source>
        <translation type="unfinished">Flytta till nästa bild</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="752"/>
        <source>Remove Current Slide</source>
        <translation type="unfinished">Ta bort nuvarande bild</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="767"/>
        <source>Add Slide After Current</source>
        <translation type="unfinished">Lägg till bild efter nuvarande</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="863"/>
        <source>Slide Title</source>
        <translation type="unfinished">Bildtitel</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="874"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Content&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Innehåll&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="887"/>
        <source>Slide Content (HTML allowed)</source>
        <translation type="unfinished">Bildinnehåll (HTML tillåtet)</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="975"/>
        <source>Longitude, Latitude</source>
        <translation type="unfinished">Longitud, Latitud</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="1056"/>
        <source>Zoom Level</source>
        <translation type="unfinished">Zoomnivå</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="1066"/>
        <source>Get Position and Zoom from Canvas</source>
        <translation type="unfinished">Hämta Position och Zoom från kartan</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="658"/>
        <source>Option:</source>
        <translation type="unfinished">Alternativ:</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="729"/>
        <source>If supported by selected style!</source>
        <translation type="unfinished">Om det stöds av vald stil!</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="1124"/>
        <source>Testing Comments (build 2016-07-30):
- ALL active vector layers exported to destination folder as un-styled GeoJSON and included in story
- Rasterlayers in jpg or png exported to destination folder! (TIFF not supported by Open Layers 3)
- WMS Layers also added as layers!
- &quot;Option&quot; -- not yet implemented!
- Advance story by clicking on title.
- Templates and styles are in plugin folder &quot;storysource&quot;. Can be edited and more added!

Send comments to: klaskarlsson@hotmail.com</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
