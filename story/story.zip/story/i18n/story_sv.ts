<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0">
<context>
    <name>@default</name>
    <message>
        <location filename="test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation type="unfinished">God Morgon</translation>
    </message>
</context>
<context>
    <name>story</name>
    <message>
        <location filename="story.py" line="217"/>
        <source>&amp;Story</source>
        <translation type="unfinished">&amp;Berättelse</translation>
    </message>
    <message>
        <location filename="story.py" line="186"/>
        <source>Story</source>
        <translation type="unfinished">Berättelse</translation>
    </message>
    <message>
        <location filename="story.py" line="529"/>
        <source>Slide Title</source>
        <translation type="unfinished">Bildrubrik</translation>
    </message>
    <message>
        <location filename="story.py" line="530"/>
        <source>Content</source>
        <translation type="unfinished">Innehåll</translation>
    </message>
    <message>
        <location filename="story.py" line="337"/>
        <source>Message!</source>
        <translation type="unfinished">Meddelande!</translation>
    </message>
    <message>
        <location filename="story.py" line="435"/>
        <source>Slide %s/%s</source>
        <translation type="unfinished">Bild %s/%s</translation>
    </message>
    <message>
        <location filename="story.py" line="515"/>
        <source>The main Story Title</source>
        <translation type="unfinished">Berättelsens Huvudtitel</translation>
    </message>
    <message>
        <location filename="story.py" line="277"/>
        <source>Continue?</source>
        <translation type="unfinished">Fortsätt?</translation>
    </message>
    <message>
        <location filename="story.py" line="277"/>
        <source>Remove Current Slide?</source>
        <translation type="unfinished">Ta bort denna bild?</translation>
    </message>
    <message>
        <location filename="story.py" line="310"/>
        <source>Open or create New story file</source>
        <translation type="unfinished">Öppna eller skapa en ny Berättelse</translation>
    </message>
    <message>
        <location filename="story.py" line="337"/>
        <source>This file does not exist!</source>
        <translation type="unfinished">Denna fil finns inte!</translation>
    </message>
    <message>
        <location filename="story.py" line="347"/>
        <source>Save New or Replace Current StoryFile</source>
        <translation type="unfinished">Spara Ny eller ersätt nuvarande Berättelse</translation>
    </message>
    <message>
        <location filename="story.py" line="380"/>
        <source>Select folder to generate story</source>
        <translation type="unfinished">Välj katalog att skapa Berättelse</translation>
    </message>
</context>
<context>
    <name>storyDockWidgetBase</name>
    <message>
        <location filename="story_dockwidget_base.ui" line="744"/>
        <source>Title</source>
        <translation type="unfinished">Titel</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="275"/>
        <source>Style</source>
        <translation type="unfinished">Stil</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="415"/>
        <source>Story File</source>
        <translation type="unfinished">Berrättelse Fil</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="660"/>
        <source>Slide n/nn</source>
        <translation type="unfinished">Bild n/nn</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="969"/>
        <source>Zoom</source>
        <translation type="unfinished">Zoom</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="869"/>
        <source>Position</source>
        <translation type="unfinished">Position</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="27"/>
        <source>Story</source>
        <translation type="unfinished">Berättelse</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="43"/>
        <source>&lt;b&gt;Main&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Generellt&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="406"/>
        <source>&lt;b&gt;File&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Filer&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="615"/>
        <source>&lt;b&gt;Slides&lt;/b&gt;</source>
        <translation type="unfinished">&lt;b&gt;Bilder&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="169"/>
        <source>Main Story Title</source>
        <translation type="unfinished">Berättelsent Titel</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="180"/>
        <source>Template</source>
        <translation type="unfinished">Mall</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="264"/>
        <source>Select Story Template</source>
        <translation type="unfinished">Välj Mall</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="386"/>
        <source>Select Story Style</source>
        <translation type="unfinished">Välj Stil</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="505"/>
        <source>Current Story Save File</source>
        <translation type="unfinished">Nuvarande Berättelsefil</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="512"/>
        <source>Clear Story Save Path</source>
        <translation type="unfinished">Rensa Berättelsesökväg</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="544"/>
        <source>Open Story</source>
        <translation type="unfinished">Öppna Berättelse</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="559"/>
        <source>Save Story</source>
        <translation type="unfinished">Spara Berättelse</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="574"/>
        <source>Create/Publish Story</source>
        <translation type="unfinished">Skapa/Publicera Berättelse</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="624"/>
        <source>Move to Previous Slide</source>
        <translation type="unfinished">Flytta till Tidigare</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="642"/>
        <source>Move Slide Earlier</source>
        <translation type="unfinished">Flytta bild tidigare</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="667"/>
        <source>Move Slide Later</source>
        <translation type="unfinished">Flytta bild till senare</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="682"/>
        <source>Move to Next Slide</source>
        <translation type="unfinished">Flytta till nästa bild</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="710"/>
        <source>Remove Current Slide</source>
        <translation type="unfinished">Ta bort nuvarande bild</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="725"/>
        <source>Add Slide After Current</source>
        <translation type="unfinished">Lägg till bild efter nuvarande</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="834"/>
        <source>Slide Title</source>
        <translation type="unfinished">Bildtitel</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="845"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Content&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Innehåll&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="858"/>
        <source>Slide Content (HTML allowed)</source>
        <translation type="unfinished">Bildinnehåll (HTML tillåtet)</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="959"/>
        <source>Longitude, Latitude</source>
        <translation type="unfinished">Longitud, Latitud</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="1040"/>
        <source>Zoom Level</source>
        <translation type="unfinished">Zoomnivå</translation>
    </message>
    <message>
        <location filename="story_dockwidget_base.ui" line="1050"/>
        <source>Get Position and Zoom from Canvas</source>
        <translation type="unfinished">Hämta Position och Zoom från kartan</translation>
    </message>
</context>
</TS>
